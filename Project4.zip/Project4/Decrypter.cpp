#include "provided.h"
#include "MyHash.h"
#include <string>
#include <vector>
using namespace std;

class DecrypterImpl
{
public:
    DecrypterImpl();
    ~DecrypterImpl();
    bool load(string filename);
    vector<string> crack(const string& ciphertext);
private:
    WordList* m_wordList;
    void crackHelper(const string& ciphertext, Translator& t, vector<string>& output);
    bool fullyTranslated(const string& s) const;
    bool completeMessage(const string& message) const;
};

DecrypterImpl::DecrypterImpl()
{
    m_wordList = new WordList;
}

DecrypterImpl::~DecrypterImpl()
{
    delete m_wordList;
}
bool DecrypterImpl::load(string filename)
{
    return m_wordList->loadWordList(filename);
}

vector<string> DecrypterImpl::crack(const string& ciphertext)
{
    Translator t;
    vector<string> output;
    Tokenizer token("0123456789,;:.!()[]{}-\"#$%^& ");
    vector<string> cipherWords = token.tokenize(ciphertext);
    
    crackHelper(ciphertext, t, output);
    
    // Insertion sort
    for (int i = 2; i < output.size() + 1; i++)
    {
        string sort = output[i-1];
        int index = i - 2;
        while (index >= 0 && sort < output[index])
        {
            output[index+1] = output[index];
            index--;
        }
        output[index+1] = sort;
    }
    return output;
}

void DecrypterImpl::crackHelper(const string& ciphertext, Translator& t, vector<string>& output)
{
    // 0. Base case
    if (ciphertext.size() == 0)
        return;
    // 1. Break up the ciphertext
    Tokenizer token("1234567890,;:.!()[]{}-\"#$%^& ");
    vector<string> words = token.tokenize(ciphertext);
    
    // 2. Pick the word
         // (1) Not chosen
         // (2) Has the most '?'
    int maxQues = 0;
    size_t maxLength = 0;
    int index = 0;
    vector<string> partialTrans;
    for (int i = 0; i < words.size(); i++)
    {
        partialTrans.push_back(t.getTranslation(words[i]));
        int nQues = 0;
        size_t size = partialTrans[i].size();
        for (int j = 0; j < partialTrans[i].size(); j++)
        {
            if (partialTrans[i][j] == '?')
                nQues++;
        }
        if (nQues > maxQues && size > maxLength)
        {
            index = i;
            maxQues = nQues;
            maxLength = size;
        }
    }
    
    if (words.size() == 0 || partialTrans.size() == 0)
        return;
    string w = words[index];
    string currTr = partialTrans[index];
   
    // 4. Find candidates
    vector<string> candidates;
    if (m_wordList != nullptr)
        candidates = m_wordList->findCandidates(w, currTr);
    
    // 5. Empty candidates
    if (candidates.empty())
    {
        t.popMapping();
        return;
    }
    
    // 6. Examine the candidates
    string translation;
    for (int i = 0; i < candidates.size(); i++)
    {
        // 6a. Push the new mapping
        Translator temp;
        string plaintext;
        string ct;
        string currMap = t.getTranslation("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        for (int i = 0; i < currMap.size(); i++)
        {
            if (currMap[i] != '?' && isalpha(currMap[i]))
            {
                ct += 'A' + i;
                plaintext += currMap[i];
            }
        }
        if (!temp.pushMapping(ct, plaintext))
        {
            cerr << "Temp mapping should be empty." << endl;
            exit(1);
        }
        if (!temp.pushMapping(w, candidates[i]))
            continue;
        
        // 6b. Translate the ciphertext
        translation = temp.getTranslation(ciphertext);
        Tokenizer token("0123456789,;:.!()[]{}-\"#$%^& ");
        vector<string> message = token.tokenize(translation);
        
        // 6c. Evaluate
        if (completeMessage(translation))
        {
            // Message is complete
            output.push_back(translation);
            temp.popMapping();
            continue;
        }
        else
        {
            bool valid = true;
            for (int i = 0; i < message.size(); i++)
            {
                // Message is not complete, a fully translated word is not in the wordlist
                if (fullyTranslated(message[i]) && !m_wordList->contains(message[i]))
                {
                    temp.popMapping();
                    valid = false;
                }
            }
            if (!valid)
                continue;
            
            // Message is not complete, all fully translated words are in the wordlist
            crackHelper(ciphertext, temp, output);
        }
    }
    // 7. After checking all the candidates
    t.popMapping();
    return;
}

bool DecrypterImpl::fullyTranslated(const string& s) const
{
    for (int i = 0; i < s.size(); i++)
        if (s[i] == '?')
            return false;
    return true;
}

bool DecrypterImpl::completeMessage(const string& message) const
{
    if (message.size() == 0)
        return false;
    Tokenizer token("1234567890,;:.!()[]{}-\"#$%^& ");
    vector<string> words = token.tokenize(message);
    for (int i = 0; i < words.size(); i++)
    {
        if (fullyTranslated(words[i]) && !m_wordList->contains(words[i]))
            return false;
        for (int j = 0; j < words[i].size(); j++)
            if (words[i][j] == '?')
                return false;
    }
    return true;
}

//******************** Decrypter functions ************************************

// These functions simply delegate to DecrypterImpl's functions.
// You probably don't want to change any of this code.

Decrypter::Decrypter()
{
    m_impl = new DecrypterImpl;
}

Decrypter::~Decrypter()
{
    delete m_impl;
}

bool Decrypter::load(string filename)
{
    return m_impl->load(filename);
}

vector<string> Decrypter::crack(const string& ciphertext)
{
   return m_impl->crack(ciphertext);
}

